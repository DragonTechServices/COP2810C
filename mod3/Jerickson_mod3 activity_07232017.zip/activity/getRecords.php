<?php
include 'config.php';
include 'openDB.php';



?>
<html>
	<head>
	
	</head>
	<body>
	
	<?php
		


?>
	</body>
</html>

