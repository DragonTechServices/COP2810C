<?php
// This is an example of config.php
$dbhost = 'localhost';
$dbuser = 'appuser';
$dbpass = 'dbprogramming2017';
$dbname = 'cop2810c';
?>